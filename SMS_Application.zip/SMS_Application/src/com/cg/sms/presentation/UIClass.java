package com.cg.sms.presentation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.cg.sms.model.Student;
import com.cg.sms.service.StudentService;
import com.cg.sms.service.StudentServiceIMPL;

public class UIClass {
	public static void main(String[] args) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("1.Insert Student");
		System.out.println("2.Delete Student");
		System.out.println("3.update student details");
		System.out.println("4.select all students");
		System.out.println("5.select Student by ID");
System.out.println("select ur choice:");
int input = scanner.nextInt();
	StudentService service = new StudentServiceIMPL();
switch (input) {
case 1:
	scanner.nextLine();
System.out.println("Enter Name:");
String name = scanner.nextLine();
System.out.println("designation");
String desig = scanner.nextLine();
System.out.println("salary");
double salary = scanner.nextDouble();
Student student = new Student();
student.setName(name);
student.setDesig(desig);
student.setSalary(salary);
try{
int result = service.addStudent(student);
System.out.println(result+"inserted");}
catch(ClassNotFoundException|IOException e){
	e.printStackTrace();
}
	break;
case 2:
	System.out.println("enter id to delete");
	int studentid= scanner.nextInt();
	int resul=service.deleteStudent(studentid);
	System.out.println(resul+"record deleted with id"+studentid);
	break;
case 3:
	System.out.println("Enter id:");
	int id= scanner.nextInt();
	scanner.nextLine();
	System.out.println("Enter desig to update");
	String designation = scanner.nextLine();
	Student student2 = new Student();
	student2.setId(id);
	student2.setDesig(designation);
	try{
	int res = service.updateStudent(student2);
	System.out.println(res+ "updated with id"+id);
	}catch(ClassNotFoundException|IOException|SQLException e){
		e.printStackTrace();	
	}
	break;
case 4:
	try {
		List<Student> list = service.getAllStudents();

		for (Student student3 : list) {
			System.out.println(student3.getId() + ":" + student3.getName() + ":" + student3.getDesig() + ":"
					+ student3.getSalary());
		}

	} catch (ClassNotFoundException | IOException | SQLException e) {
		e.printStackTrace();
	}

	break;
	

	
default:
	break;
}
	}

}
