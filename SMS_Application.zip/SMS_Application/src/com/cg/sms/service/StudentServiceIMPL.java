package com.cg.sms.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.sms.dao.StudentDao;
import com.cg.sms.dao.StudentDaoIMPS;
import com.cg.sms.model.Student;

public class StudentServiceIMPL implements StudentService {

StudentDao studentDao = new StudentDaoIMPS();
	public int addStudent(Student student) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {

		return studentDao.addStudent(student);
	}

	public int deleteStudent(int id)  throws ClassNotFoundException, FileNotFoundException, SQLException, IOException {
	
		return studentDao.deleteStudent(id);
	}

	@Override
	public int updateStudent(Student student) throws ClassNotFoundException,
			FileNotFoundException, SQLException, IOException {
	int res = studentDao.updateStudent(student);
		return res;
	}

	public List<Student> getAllStudents() throws ClassNotFoundException,
			FileNotFoundException, SQLException, IOException {
		List<Student> list = studentDao.getAllStudents();
		return list;
	}

}
