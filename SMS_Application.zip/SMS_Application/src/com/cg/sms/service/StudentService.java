package com.cg.sms.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.sms.model.Student;

public interface StudentService {
	public int addStudent(Student student) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;
	public int deleteStudent(int id) throws ClassNotFoundException, FileNotFoundException, SQLException, IOException;
		public int updateStudent(Student student) throws ClassNotFoundException, FileNotFoundException,SQLException,IOException;
		public List<Student> getAllStudents() throws ClassNotFoundException, FileNotFoundException,SQLException,IOException;
	}


